<?php
/*session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir a la página de inicio de sesión
    header('Location: ../iniciar.php');
    exit(); // Salir para evitar que el código continúe ejecutándose
}*/

include_once("../php/conexion.php");

$tipoCartas = [];
$sql = "SELECT TipoCarta, NombreTipoCarta FROM [dbo].[TipoCartas]";
$result = $conn->query($sql);
if ($result->rowCount() > 0) {
    $tipoCartas = $result->fetchAll(PDO::FETCH_ASSOC);
}

$id = null; $tipoCarta = null; $nombreCarta = null; $poderAtaque = null; $poderDefensa = null;
if (isset($_GET["id"])) {
    $sql = "SELECT IdCarta, TipoCarta, NombreCarta, PoderAtaque, PoderDefensa FROM [dbo].[Cartas] WHERE IdCarta='" . $_GET["id"] . "'";
    $result = $conn->query($sql);
    if ($result->rowCount() > 0) {
        $row = $result->fetch(PDO::FETCH_ASSOC);
        $id = $row["IdCarta"];
        $tipoCarta = $row["TipoCarta"];
        $nombreCarta = $row["NombreCarta"];
        $poderAtaque = $row["PoderAtaque"];
        $poderDefensa = $row["PoderDefensa"];
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="../css/style.css" rel="stylesheet">
    <title>Nueva Carta</title>
    <link rel="icon" href="../img/carta.png" type="image/png">
</head>
<body>
    <div class="container">
        <div class="content">
            <h1>Nueva Carta</h1>
            <div id="form">
                <form action="../php/crudcartas.php" method="post" id="formCarta">
                    <label class="form-label">Tipo de Carta</label>
                    <select class="form-control" id="tipoCarta" name="tipoCarta" required>
                        <option value="">Seleccione un tipo</option>
                        <?php foreach ($tipoCartas as $tipo): ?>
                            <option value="<?php echo $tipo['TipoCarta']; ?>" <?php if (isset($tipoCarta) && $tipoCarta == $tipo['TipoCarta']) echo 'selected'; ?>>
                                <?php echo $tipo['NombreTipoCarta']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select><br>
                    <label class="form-label">Nombre de la Carta</label>
                    <input class="form-control" type="text" id="nombreCarta" name="nombreCarta" placeholder="Nombre de la Carta" required value="<?php echo $nombreCarta; ?>"><br>
                    <label class="form-label">Poder de Ataque</label>
                    <input class="form-control" type="number" id="poderAtaque" name="poderAtaque" placeholder="Poder de Ataque" required value="<?php echo $poderAtaque; ?>"><br>
                    <label class="form-label">Poder de Defensa</label>
                    <input class="form-control" type="number" id="poderDefensa" name="poderDefensa" placeholder="Poder de Defensa" required value="<?php echo $poderDefensa; ?>"><br>
                    <row>
                        <button class="btn btn-primary" id="guardar" name="guardar">Guardar</button>
                        <button class="btn btn-secondary" onclick="window.location.href='cartas.php';">Regresar</button>
                    </row>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="../js/cartas.js"></script>
</body>
</html>