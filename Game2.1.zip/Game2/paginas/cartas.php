<?php
/*session_start();

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['usuario_id'])) {
    // Redirigir a la página de inicio de sesión
    header('Location: ../iniciar.php');
    exit(); // Salir para evitar que el código continúe ejecutándose
}*/
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="../css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Cartas</title>
    <link rel="icon" href="../img/carta.png" type="image/png">
</head>
<body>
    <div class="container">
        <div class="content">

            <h1 class="text-center">Gestión de Cartas</h1>
            <button class="btn btn-primary" onclick="window.location.href='../paginas/FormCrearCarta.php';">Nuevo</button>
            <div id="listado">
                <?php
                include_once("../php/CrudCartas.php");

                echo '<table class="table"><thead>
                    <tr scope="row"><th>ID</th><th>Tipo</th><th>Nombre</th><th>Poder Ataque</th><th>Poder Defensa</th><th>Operaciones</th></tr>
                    </thead><tbody>';
                
                $cartas = obtenerCartas($conn);
                
                if (count($cartas) > 0) {
                    foreach ($cartas as $row) {
                        echo '<tr scope="row"><td>' . $row["IdCarta"] . '</td><td>' . $row["NombreTipoCarta"] . '</td><td>' . $row["NombreCarta"] . '</td><td>' . $row["PoderAtaque"] . '</td><td>' . $row["PoderDefensa"] . '</td>';
                        echo '<td>
                            <a href="../actualizar/actualizar_carta.php?id=' . $row["IdCarta"] . '" class="btn btn-warning"><i class="fa fa-edit"></i></a>
                            <form action="../crud/crud_carta.php" method="post" style="display:inline;" onsubmit="return confirm(\'¿Estás seguro de que deseas eliminar esta carta?\');">
                                <input type="hidden" name="carta_id" value="' . $row["IdCarta"] . '">
                                <button class="btn btn-danger" id="eliminar" name="eliminar" type="submit"><i class="fa fa-trash"></i></button>
                            </form>
                        </td></tr>';
                    }
                } else {
                    echo '<tr><td colspan="6" class="text-center">No se encontraron registros.</td></tr>';
                }
                echo "</tbody></table>";
                $conn = null;
                ?>
            </div>

        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="../script.js"></script>
</body>

</html>