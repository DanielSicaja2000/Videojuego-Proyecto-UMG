<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Base de datos</title>
    <style>
    
        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background: linear-gradient(to bottom, #f0f4f8, #cce0ff);
            overflow: hidden;
        }
        header {
            width: 100%;
            background-color: #2e4053;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 24px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
        }
        .container {
            display: flex;
            width: 100%;
            height: calc(100% - 100px);
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            gap: 10px;
            padding: 20px;
            height: 100%;
            width: 50%;
            overflow-y: auto;
            background-color: #000000;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
        }
        .card {
            text-align: center;
            cursor: pointer;
            position: relative;
        }
        .card img {
            width: 100%;
            border-radius: 10px;
            transition: transform 0.3s ease;
        }
        .card img:hover {
            transform: scale(1.50);
        }
        .card p {
            font-weight: bold;
            color: white;
            margin: 10px 0 0;
        }
        .card input[type="checkbox"] {
            position: absolute;
            top: 10px;
            left: 10px;
            transform: scale(1.5);
            cursor: pointer;
            z-index: 1;
            transition: transform 0.3s ease;
        }
        .card:hover input[type="checkbox"] {
            transform: scale(1.8);
        }
        .featured-image-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            padding: 20px;
            width: 50%;
            position: relative;
            z-index: 1;
        }
        .featured-image-container img {
            max-width: 400px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s ease;
        }
        .featured-image-container img:hover {
            transform: scale(1.05);
        }
        .featured-image-container p {
            font-size: 24px;
            margin-top: 10px;
        }
        #featuredId {
            font-size: 18px;
            color: gray;
            margin-top: 10px;
        }
        #generateDeckButton {
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
            transition: background-color 0.3s ease;
        }
        #generateDeckButton:hover {
            background-color: #0056b3;
        }
        footer {
            width: 100%;
            background-color: #2e4053;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 16px;
            position: absolute;
            bottom: 0;
            left: 0;
            box-shadow: 0 -2px 5px rgba(0, 0, 0, 0.3);
        }
    </style>
</head>
<body>

<header>
    Base De Datos Yu Gi Oh
</header>

<div class="container">
    <div class="grid-container" id="grid">
        <?php
        // URL de la API
        $apiUrl = "https://db.ygoprodeck.com/api/v7/cardinfo.php?id=89718302,70832512,12600382,62320425,83994646,75081613,14553285,50789693,88819587,32452818,
5405694,89631139,23995346,53183600,95727991,91152256,67494157,28279543,46986414,62873545,66672569,45231177,77456781,41392891,25833572,13039848,
76812113,52040216,94773007,30113682,62340868,97590747,69455834,84814897,46237548,176392,67050396,90147755,77568553,77568553,9464441,36904469";
        // Obtener el contenido JSON de la API
        $response = file_get_contents($apiUrl);

        if ($response) {
            $data = json_decode($response, true);

            if (isset($data['data']) && is_array($data['data'])) {
                $cards = $data['data'];
                foreach ($cards as $card) {
                    $name = $card['name'];
                    $id = $card['id'];
                    $imageUrlCropped = $card['card_images'][0]['image_url_cropped'];
                    echo "<div class='card' onclick='showFeaturedImage(\"{$card['card_images'][0]['image_url']}\", \"{$name}\", \"{$id}\")'>";
                    echo "<input type='checkbox' id='checkbox_{$id}' data-id='{$id}' onchange='checkLimit()'>";
                    echo "<img src='{$imageUrlCropped}' alt='{$name}'>";
                    echo "<p>{$name}</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No se encontraron datos de cartas.</p>";
            }
        } else {
            echo "<p>Error al conectar con la API.</p>";
        }
        ?>
    </div>

    <div class="featured-image-container">
        <img src="" alt="Carta Destacada" id="featuredImage">
        <p id="featuredName"></p>
        <p id="featuredId">ID: 91152256</p> <!-- Establecer el ID deseado inicialmente -->
        <button id="generateDeckButton" onclick="generateDeck()">Generar Deck</button>
        <button id="insertar" >Insert</button>
    </div>
</div>

<footer>
    © 2024 - Juego de cartas - Desarrollo Web - MARIANO GALVEZ
</footer>

<script>
    const featuredImage = document.getElementById('featuredImage');
    const featuredName = document.getElementById('featuredName');
    const featuredId = document.getElementById('featuredId'); // Elemento para mostrar el ID

    // Función para mostrar la imagen destacada, nombre y ID
    function showFeaturedImage(imageUrl, name, id) {
        featuredImage.src = imageUrl;
        featuredName.textContent = name;
        featuredId.textContent = "ID: " + id; // Mostrar el ID
    }

    // Función para verificar la cantidad de checkboxes seleccionados
    function checkLimit() {
        const checkboxes = document.querySelectorAll('.grid-container input[type="checkbox"]');
        let checkedCount = 0;

        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                checkedCount++;
            }
        });

        if (checkedCount > 8) {
            alert("Solo puedes seleccionar hasta 8 cartas.");
            checkboxes[checkboxes.length - 1].checked = false; // Desmarcar el último checkbox
        }
    }

    // Función para generar el deck
    function generateDeck() {
        const selectedIds = [];
        const checkboxes = document.querySelectorAll('.grid-container input[type="checkbox"]');

        checkboxes.forEach(checkbox => {
            if (checkbox.checked) {
                selectedIds.push(checkbox.dataset.id);
            }
        });

        if (selectedIds.length === 0) {
            alert("No has seleccionado ninguna carta.");
        } else {
            alert("ID de cartas seleccionadas: " + selectedIds.join(", "));
        }
    }

    // Mostrar la carta con el ID 91152256 al cargar la página
    window.onload = function() {
        const targetId = "91152256"; // ID que queremos mostrar
        const targetCard = Array.from(document.querySelectorAll('.grid-container .card')).find(card => {
            return card.querySelector('input[type="checkbox"]').dataset.id === targetId;
        });

        if (targetCard) {
            const imageUrl = targetCard.querySelector('input[type="checkbox"]').dataset.id;
            const name = targetCard.querySelector('p').textContent;
            const imageUrlFull = targetCard.querySelector('img').src.replace('_cropped', ''); // Reemplazar la parte _cropped
            showFeaturedImage(imageUrlFull, name, targetId);
        }
    };


    document.getElementById('insertar').onclick = function() {
    const selectedIds = [];
    const checkboxes = document.querySelectorAll('.grid-container input[type="checkbox"]');

    checkboxes.forEach(checkbox => {
        if (checkbox.checked) {
            selectedIds.push(checkbox.dataset.id);
        }
    });

    if (selectedIds.length !== 8) {
        alert("Debes seleccionar exactamente 8 cartas.");
        return;
    }

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "../php/insertMazos.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function() {
        if (xhr.status === 200) {
            const response = JSON.parse(xhr.responseText);
            alert(response.message || response.error);
        } else {
            alert("Hubo un error al procesar la solicitud.");
        }
    };

    xhr.send("selectedIds=" + JSON.stringify(selectedIds));
};




</script>

</body>
</html>
