<?php
session_start(); // Iniciar la sesión

// Verificar si el usuario ha iniciado sesión
if (!isset($_SESSION['idUsuario'])) {
    echo json_encode(['status' => 'error', 'message' => 'No hay sesión activa.']);
    exit();
}

// Obtener el ID del usuario desde la sesión
$idUsuario = $_SESSION['idUsuario'];
$cantidad = 8; // Cantidad fija
$fechaCreacion = date('Y-m-d'); // Fecha actual
$estadoMazo = "activo"; // Estado del mazo

// Conexión a la base de datos
require 'conexion.php';

try {
    // Preparar la consulta de inserción
    $stmt = $conn->prepare("INSERT INTO mazo (IdUsuario, Cantidad, FechaCreación, EstadoMazo) VALUES (:IdUsuario, :Cantidad, :FechaCreación, :EstadoMazo)");
    
    // Vincular los parámetros
    $stmt->bindParam(':IdUsuario', $idUsuario);
    $stmt->bindParam(':Cantidad', $cantidad);
    $stmt->bindParam(':FechaCreación', $fechaCreacion);
    $stmt->bindParam(':EstadoMazo', $estadoMazo);

    // Ejecutar la consulta
    $stmt->execute();

    echo json_encode(['status' => 'success', 'message' => 'Mazo insertado correctamente.']);
} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error al insertar el mazo: ' . $e->getMessage()]);
}
?>
