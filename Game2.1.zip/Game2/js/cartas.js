document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("formCarta");

    form.addEventListener("submit", function(event) {
        const tipoCarta = document.getElementById("tipoCarta").value;
        const nombreCarta = document.getElementById("nombreCarta").value;
        const poderAtaque = document.getElementById("poderAtaque").value;
        const poderDefensa = document.getElementById("poderDefensa").value;

        if (!tipoCarta || !nombreCarta || !poderAtaque || !poderDefensa) {
            alert("Todos los campos son obligatorios.");
            event.preventDefault();
        }

        if (isNaN(poderAtaque) || isNaN(poderDefensa)) {
            alert("Poder de Ataque y Poder de Defensa deben ser números.");
            event.preventDefault();
        }
    });
});