<?php
$host = 'proyectosazure.database.windows.net';
$dbname = 'ProyectoDesarrollo';
$username = 'adminSergio';
$password = 'Umg$2024';

try {
    $dsn = "sqlsrv:server=$host;database=$dbname";
    $options = array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    );

    $conn = new PDO($dsn, $username, $password, $options);
    echo "Conexio Correcta";
} catch (PDOException $e) {
    echo "Error de conexión: " . $e->getMessage();
}
?>