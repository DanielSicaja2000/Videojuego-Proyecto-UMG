<?php
session_start();
include 'conexion.php';

if (!isset($_SESSION['usuario']) || !isset($_SESSION['idUsuario'])) {
    header("Location: iniciar.php");
    exit();
}

$idUsuario = $_SESSION['idUsuario'];

function insertarMazo($conn, $idUsuario) {
    $cantidad = 8; 
    $estadoMazo = "activo"; 
    $fechaCreacion = date("Y-m-d");

    try {
        // Insertar nuevo mazo
        $sql = "INSERT INTO mazo (IdUsuario, Cantidad, FechaCreación, EstadoMazo) VALUES (:idUsuario, :cantidad, :fechaCreacion, :estadoMazo)";
        $stmt = $conn->prepare($sql);
        
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->bindParam(':cantidad', $cantidad);
        $stmt->bindParam(':fechaCreacion', $fechaCreacion);
        $stmt->bindParam(':estadoMazo', $estadoMazo);
        
        $stmt->execute();
        
        // Obtener el último IdMazo insertado
        $idMazo = $conn->lastInsertId();
        
        return ["success" => true, "message" => "Mazo registrado exitosamente.", "idMazo" => $idMazo];
    } catch (PDOException $e) {
        return ["success" => false, "error" => "Error: " . $e->getMessage()];
    }
}

function insertarMazoCarta($conn, $idMazo, $selectedIds) {
    try {
        // Preparar consulta para insertar en MazoCarta
        $sql = "INSERT INTO MazoCarta (IdMazo, IdCarta) VALUES (:idMazo, :idCarta)";
        $stmt = $conn->prepare($sql);

        // Insertar cada carta seleccionada en MazoCarta
        foreach ($selectedIds as $idCarta) {
            $stmt->bindParam(':idMazo', $idMazo);
            $stmt->bindParam(':idCarta', $idCarta);
            $stmt->execute();
        }

        return ["success" => true, "message" => "Cartas añadidas al mazo exitosamente."];
    } catch (PDOException $e) {
        return ["success" => false, "error" => "Error al insertar cartas: " . $e->getMessage()];
    }
}

// Manejar la solicitud AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedIds = json_decode($_POST['selectedIds']); // Obtener los ID seleccionados desde AJAX

    $result = insertarMazo($conn, $idUsuario);

    if ($result['success']) {
        $idMazo = $result['idMazo'];
        $insertCartasResult = insertarMazoCarta($conn, $idMazo, $selectedIds);
        echo json_encode($insertCartasResult);
    } else {
        echo json_encode($result);
    }

    exit();
}
?>
