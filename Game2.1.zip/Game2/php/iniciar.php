<?php
// Incluir el archivo de conexión
require 'conexion.php';
session_start(); // Iniciar la sesión

// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $correo = $_POST['correo'];
    $contraseña = $_POST['contraseña'];

    // Registrar los datos recibidos en el log
    error_log("Datos recibidos del formulario de inicio de sesión:");
    error_log("Correo electrónico: $correo");
    error_log("Contraseña: $contraseña");

    try {
        // Preparar la consulta para obtener el usuario y la contraseña
        $stmt = $conn->prepare(
            "SELECT j.IdUsuario, j.CorreoUsuario, c.Contraseña 
            FROM Jugador j
            JOIN ContraseñaUsuarios c ON j.IdUsuario = c.IdUsuario
            WHERE j.CorreoUsuario = :CorreoUsuario"
        );

        // Vincular el parámetro
        $stmt->bindParam(':CorreoUsuario', $correo);

        // Ejecutar la consulta
        $stmt->execute();

        // Obtener el resultado
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verificar si se encontró el usuario y si la contraseña coincide
        if ($usuario && password_verify($contraseña, $usuario['Contraseña'])) {
            // Iniciar sesión y guardar datos del usuario en la sesión
            $_SESSION['usuario'] = $usuario['CorreoUsuario'];
            $_SESSION['idUsuario'] = $usuario['IdUsuario']; // Almacenar el IdUsuario

            // Redirigir a principal.html
            header("Location: ../paginas/principal.html");
            exit();
        } else {
            // Credenciales incorrectas
            $_SESSION['error'] = "Correo electrónico o contraseña incorrectos.";
            header("Location: ../paginas/iniciar.php");
            exit();
        }
    } catch (PDOException $e) {
        // Manejar errores y registrar el mensaje de error en el log
        error_log("Error al validar las credenciales: " . $e->getMessage());
        $_SESSION['error'] = "Error al validar las credenciales.";
        header("Location: ../paginas/iniciar.php");
        exit();
    }
}
?>
