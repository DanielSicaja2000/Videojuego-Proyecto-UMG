/****** Object:  Table [dbo].[ContraseñaUsuarios]    Script Date: 15/10/2024 18:13:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ContraseñaUsuarios](
	[idCorrelativo] [int] IDENTITY(1,1) NOT NULL,
	[IdUsuario] [int] NOT NULL,
	[Contraseña] [varchar](100) NOT NULL,
	[EstadoContraseña] [varchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[idCorrelativo] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ContraseñaUsuarios]  WITH CHECK ADD  CONSTRAINT [FK_ContraseñaUsuarios_IdUsuario] FOREIGN KEY([IdUsuario])
REFERENCES [dbo].[Jugador] ([IdUsuario])
GO

ALTER TABLE [dbo].[ContraseñaUsuarios] CHECK CONSTRAINT [FK_ContraseñaUsuarios_IdUsuario]
GO

----------------------------------------------------------------------------
/****** Object:  Table [dbo].[Jugador]    Script Date: 15/10/2024 18:14:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Jugador](
	[IdUsuario] [int] IDENTITY(1,1) NOT NULL,
	[NombreUsuario] [varchar](50) NOT NULL,
	[NombreReal] [varchar](50) NOT NULL,
	[CorreoUsuario] [varchar](50) NOT NULL,
	[TipoUsuario] [int] NOT NULL,
	[FechaRegistro] [date] NOT NULL,
	[EstadoUsuario] [varchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[IdUsuario] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[CorreoUsuario] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Jugador]  WITH CHECK ADD  CONSTRAINT [FK_Jugador_TipoUsuario] FOREIGN KEY([TipoUsuario])
REFERENCES [dbo].[UsuarioTipo] ([TipoUsuario])
GO

ALTER TABLE [dbo].[Jugador] CHECK CONSTRAINT [FK_Jugador_TipoUsuario]
GO
----------------------------------------------------------------------------
/****** Object:  Table [dbo].[UsuarioTipo]    Script Date: 15/10/2024 18:14:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UsuarioTipo](
	[TipoUsuario] [int] IDENTITY(1,1) NOT NULL,
	[NombreTipoUsuario] [varchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[TipoUsuario] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

----------------------------------------------------------------------------

/****** Object:  Table [dbo].[Cartas]    Script Date: 28/10/2024 21:43:03 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Cartas](
	[IdCarta] [int] IDENTITY(1,1) NOT NULL,
	[TipoCarta] [int] NOT NULL,
	[NombreCarta] [varchar](100) NOT NULL,
	[PoderAtaque] [int] NOT NULL,
	[PoderDefensa] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[IdCarta] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Cartas]  WITH CHECK ADD  CONSTRAINT [FK_Cartas_TipoCarta] FOREIGN KEY([TipoCarta])
REFERENCES [dbo].[TipoCartas] ([TipoCarta])
GO

ALTER TABLE [dbo].[Cartas] CHECK CONSTRAINT [FK_Cartas_TipoCarta]
GO

----------------------------------------------------------------------------

/****** Object:  Table [dbo].[TipoCartas]    Script Date: 28/10/2024 22:59:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TipoCartas](
	[TipoCarta] [int] IDENTITY(1,1) NOT NULL,
	[NombreTipoCarta] [varchar](20) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[TipoCarta] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

