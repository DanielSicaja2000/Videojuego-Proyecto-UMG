document.addEventListener('DOMContentLoaded', function() {
  const form = document.querySelector('#iniciar');
  const correo = document.querySelector('#correo');
  const contraseña = document.querySelector('#contraseña');

  if (form) {
    form.addEventListener('submit', function(event) {
      event.preventDefault();
      if (!correo.validity.valid) {
        alert('Por favor ingrese un correo electrónico válido.');
        return;
      }

      if (contraseña.value.length < 2) {
        alert('Debe ingresar una contraseña!');
        return;
      }
      form.submit();
    });
  }

  // Verificar si hay un mensaje de error en la sesión
  if (sessionStorage.getItem('error')) {
    Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: sessionStorage.getItem('error'),
    });
    sessionStorage.removeItem('error');
  }

  // Verificar si el elemento Header existe antes de agregar el event listener
  var header = document.getElementById('Header');
  if (header) {
    window.addEventListener('scroll', () => {
      var scroll = window.scrollY

      if (scroll > 10) {
        header.style.backgroundColor = '#196180'
      } else {
        header.style.backgroundColor = 'transparent'
      }
    });
  }
});