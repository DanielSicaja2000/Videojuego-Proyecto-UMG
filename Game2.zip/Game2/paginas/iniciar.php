<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="../CSS/IniciarSesion.css">

  <!-- jQuery via CDN -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

  <!-- bootstrap via CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">

  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <title>Log In</title>
</head>
<body>
  <?php
  session_start();
  if (isset($_SESSION['error'])) {
    echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
              Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '" . $_SESSION['error'] . "',
              });
            });
          </script>";
    unset($_SESSION['error']);
  }
  ?>
  <form id="iniciar" method="post" action="../php/iniciar.php">
    <h1>Iniciar Sesión</h1>
    <label for="correo">Correo electrónico:</label>
    <input type="email" id="correo" name="correo" autocomplete="email" required>

    <label for="contraseña">Contraseña:</label>
    <input type="password" id="contraseña" name="contraseña" autocomplete="current-password" required>

    <button class="btn" type="submit">Iniciar Sesión</button>

    <div class="registrar">
      <p>¿No estas registrado? <a href="registrar.php">Registrate aqui!</a></p>
    </div>
  </form>

  <footer class="foot">
    <div class="wrapper">
      <p>&copy; 2024 Todos los derechos reservados - Grupo #3 Desarrollo Web.</p>
    </div>
  </footer>

  <!-- enlance js local -->
  <script src="../js/iniciar.js" type="text/javascript"></script>
  <script language="javascript" type="text/javascript"
    src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.min.js"></script>
  <script language="javascript" type="text/javascript"
    src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.min.js"></script>
</body>
</html>