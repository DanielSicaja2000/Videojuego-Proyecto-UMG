<?php
include_once("conexion.php");
//Listar Cartas
function obtenerCartas($conn) {
    $sql = "SELECT C.IdCarta, TP.NombreTipoCarta, C.NombreCarta, C.PoderAtaque, C.PoderDefensa 
            FROM [dbo].[Cartas] C
            INNER JOIN [dbo].[TipoCartas] TP ON C.TipoCarta = TP.TipoCarta";
    $result = $conn->query($sql);

    if ($result->rowCount() > 0) {
        return $result->fetchAll(PDO::FETCH_ASSOC);
    } else {
        return [];
    }
}

//Insertar Carta
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $tipoCarta = $_POST["tipoCarta"];
    $nombreCarta = $_POST["nombreCarta"];
    $poderAtaque = $_POST["poderAtaque"];
    $poderDefensa = $_POST["poderDefensa"];

    if (!empty($tipoCarta) && !empty($nombreCarta) && !empty($poderAtaque) && !empty($poderDefensa)) {
        $sql = "INSERT INTO [dbo].[Cartas] (TipoCarta, NombreCarta, PoderAtaque, PoderDefensa) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$tipoCarta, $nombreCarta, $poderAtaque, $poderDefensa]);

        header("Location: ../paginas/cartas.php");
        exit();
    } else {
        echo "Todos los campos son obligatorios.";
    }
}
?>