<?php
// Incluir el archivo de conexión
include 'conexion.php';

// Obtener los datos del formulario
$nombreUsuario = $_POST['nombre-usuario'];
$nombreReal = $_POST['nombre-real'];
$correo = $_POST['correo'];
$contraseña = $_POST['contraseña'];
$tipoUsuario = 1; // Tipo de usuario por defecto
$estadoUsuario = "Activo"; // Estado por defecto
$fechaRegistro = date("Y-m-d"); // Fecha actual

// Hash de la contraseña
$hashedPassword = password_hash($contraseña, PASSWORD_DEFAULT);

try {
    // Insertar en la tabla Jugador
    $sqlJugador = "INSERT INTO Jugador (NombreUsuario, NombreReal, CorreoUsuario, TipoUsuario, FechaRegistro, EstadoUsuario)
                   VALUES (:nombreUsuario, :nombreReal, :correo, :tipoUsuario, :fechaRegistro, :estadoUsuario)";
    $stmt = $conn->prepare($sqlJugador);
    $stmt->bindParam(':nombreUsuario', $nombreUsuario);
    $stmt->bindParam(':nombreReal', $nombreReal);
    $stmt->bindParam(':correo', $correo);
    $stmt->bindParam(':tipoUsuario', $tipoUsuario);
    $stmt->bindParam(':fechaRegistro', $fechaRegistro);
    $stmt->bindParam(':estadoUsuario', $estadoUsuario);
    $stmt->execute();

    // Obtener el ID del último usuario insertado
    $idUsuario = $conn->lastInsertId();

    // Insertar en la tabla ContraseñaUsuarios
    $sqlContraseña = "INSERT INTO ContraseñaUsuarios (IdUsuario, Contraseña, EstadoContraseña)
                      VALUES (:idUsuario, :hashedPassword, :estadoUsuario)";
    $stmt = $conn->prepare($sqlContraseña);
    $stmt->bindParam(':idUsuario', $idUsuario);
    $stmt->bindParam(':hashedPassword', $hashedPassword);
    $stmt->bindParam(':estadoUsuario', $estadoUsuario);
    $stmt->execute();

    echo "Registro exitoso";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>