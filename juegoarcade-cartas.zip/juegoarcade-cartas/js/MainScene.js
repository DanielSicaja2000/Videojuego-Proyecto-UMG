import CardPlayer from '../js/CardPlayer.js';
import CardGrid from './CardGrid.js';
import Grid from './Grid.js';
import { AddButtonRestart } from './ButtonRestart.js';

export default class MainScene extends Phaser.Scene {
  constructor() {
    super('MainScene');
  }

  preload() {
    this.load.image('armor', 'assets/armor.png');
    this.load.image('card', 'assets/card.png');
    this.load.image('dead', 'assets/dead.png');
    this.load.image('deathknight', 'assets/deathknight.png');
    this.load.image('firedrake', 'assets/firedrake.png');
    this.load.image('goldendragon', 'assets/goldendragon.png');
    this.load.image('healingpotion', 'assets/healingpotion.png');
    this.load.image('kobold', 'assets/kobold.png');
    this.load.image('ogre', 'assets/ogre.png');
    this.load.image('paladin', 'assets/paladin.png');
    this.load.image('playercard', 'assets/playercard.png');
    this.load.image('restartbutton', 'assets/restartbutton.png');
    this.load.image('shield', 'assets/shield.png');
    this.load.image('troll', 'assets/troll.png');
    this.load.bitmapFont('pressstart', 'assets/pressstart.png', 'assets/pressstart.fnt');
  }

  create() {
    this.grid = new Grid({ scene: this, columns: 3, rows: 3 });

    // Primer jugador
    this.player1 = new CardPlayer({
      scene: this,
      name: 'Paladin',
      x: this.game.config.width / 2 - 100, // Ajusta la posición x
      y: this.game.config.height - 200,
      card: 'playercard',
      image: 'paladin',
      health: 16,
      depth: 1,
      ondragend: (pointer, gameObject) => {
        this.handlePlayerDragEnd(this.player1, pointer, gameObject);
      }
    });

    // Segundo jugador
    this.player2 = new CardPlayer({
      scene: this,
      name: 'Warrior', // Cambia el nombre según lo necesites
      x: this.game.config.width / 2 + 100, // Ajusta la posición x para el segundo jugador
      y: this.game.config.height - 200,
      card: 'playercard',
      image: 'paladin', // Puedes usar otra imagen si lo deseas
      health: 16,
      depth: 1,
      ondragend: (pointer, gameObject) => {
        this.handlePlayerDragEnd(this.player2, pointer, gameObject);
      }
    });
  }

  handlePlayerDragEnd(player, pointer, gameObject) {
    player.x = player.originalX;
    player.y = player.originalY;
    if (this.highlighted) {
      player.originalX = player.x = this.highlighted.x;
      this.highlighted.selected = true;
      switch (this.highlighted.cardtype) {
        case 'attack':
          player.attack(this.highlighted.value);
          this.highlighted.dead = true;
          this.highlighted.deadAnimation();
          break;
        case 'heal':
          player.health = Math.min(player.health + this.highlighted.value, player.maxHealth);
          this.highlighted.selected = true;
          break;
        case 'armor':
          player.armor = this.highlighted.value;
          break;
      }

      if (player.dead) {
        AddButtonRestart(this);
      } else {
        this.grid.fadeFrontRow();
      }
    }
  }

  update(time, delta) {
    this.grid.cards.forEach(card => card.highlighted = false);
    this.highlighted = null;
    let columnWidth = this.game.config.width / this.grid.columns;
    let xDiff1 = Math.abs(this.player1.x - this.player1.originalX);
    let xDiff2 = Math.abs(this.player2.x - this.player2.originalX);
    
    if (this.player1.y < 700 && xDiff1 < columnWidth * 1.4) {
      this.checkHighlight(this.player1, columnWidth);
    }

    if (this.player2.y < 700 && xDiff2 < columnWidth * 1.4) {
      this.checkHighlight(this.player2, columnWidth);
    }
  }

  checkHighlight(player, columnWidth) {
    if (player.x < columnWidth) {
      this.grid.cards[0].highlighted = true;
      this.highlighted = this.grid.cards[0];
    } else if (player.x > columnWidth * 2) {
      this.grid.cards[2].highlighted = true;
      this.highlighted = this.grid.cards[2];
    } else {
      this.grid.cards[1].highlighted = true;
      this.highlighted = this.grid.cards[1];
    }
  }
}
